package com.android.smartwebview.activity;

import android.Manifest;
import android.app.ActivityManager;
import android.app.AlertDialog;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.webkit.CookieManager;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import androidx.appcompat.app.AppCompatActivity;
import com.android.smartwebview.Config;
import com.android.smartwebview.ConnectionDetector;
import com.android.smartwebview.R;
import com.google.android.material.navigation.NavigationView;
import com.google.firebase.iid.FirebaseInstanceId;
import com.miguelcatalan.materialsearchview.MaterialSearchView;
import android.annotation.SuppressLint;
import androidx.annotation.Nullable;
import androidx.browser.customtabs.CustomTabsIntent;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.appcompat.widget.Toolbar;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.core.view.GravityCompat;
import android.util.Log;
import android.os.Build;
import android.widget.Toast;
import android.net.Uri;
import android.content.DialogInterface.OnClickListener;
import com.android.smartwebview.view.AdvancedWebView;
import android.widget.ProgressBar;
import com.android.smartwebview.view.SmartChromeClient;
import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdSize;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.InterstitialAd;
import com.google.android.gms.ads.MobileAds;
import java.math.BigInteger;
import java.security.SecureRandom;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import guy4444.smartrate.SmartRate;


public class MainActivity extends AppCompatActivity implements AdvancedWebView.Listener, NavigationView.OnNavigationItemSelectedListener{

    private final static int usesBeforeRateLaunch = Config.number_of_uses_before_launching_the_rate_dialog;
    private AdvancedWebView mWebView;
    protected ProgressBar mProgressBar;
    public SmartChromeClient chromeClient;
    private View errorLayout, tryAgainButtonLayout, refreshButtonLayout;
    // Functions
    ConnectionDetector mConnectionDetector;
    // Others
    public Boolean isConnected = false;
    // Logs
    String tag = "state";

    AdView mAdView;
    //Keep track of the interstitials we show
    private int interstitialCount = -1;

    private MaterialSearchView searchView;
    public Toolbar toolbar;

    private long exitTime = 0;
    private static final int PRESS_BACK_EXIT_GAP = 2000;

    public Context mContext;
    public AppCompatActivity mActivity;
    private final static int file_perm = 2;

    public static String fcm_channel = "1";
    public String fcm_token;
    public static int FCM_ID = fcm_id();
    int asw_error_counter = 0;
    private SecureRandom random = new SecureRandom();

    //Configuration variables
    private static String mobile_website_url     		= Config.mobile_website_url;
    public static String SMART_HOST			= aswm_host(mobile_website_url);

    Boolean true_online = !Config.offline_app && !mobile_website_url.startsWith("file:///");

    @SuppressLint("SetJavaScriptEnabled")
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        // Get the application context
        mContext = getApplicationContext();
        mActivity = MainActivity.this;

        toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        DrawerLayout drawer = findViewById(R.id.drawer_layout);
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(MainActivity.this, drawer, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        drawer.addDrawerListener(toggle);
        toggle.syncState();

        NavigationView navigationView = findViewById(R.id.nav_view);
        navigationView.setNavigationItemSelectedListener(MainActivity.this);

        // Declaring mConnection Detector
        mConnectionDetector = new ConnectionDetector(getApplicationContext());

        errorLayout = findViewById(R.id.error_layout);
        tryAgainButtonLayout = findViewById(R.id.tryAgainButton_layout);
        refreshButtonLayout = findViewById(R.id.refreshButton_layout);

        Button tryAgainButton = findViewById(R.id.try_again_button);
        tryAgainButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
                startActivity(getIntent());
            }
        });

        Button refreshButton = findViewById(R.id.refreshButton);
        refreshButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                refresh();
            }
        });

        mWebView = findViewById(R.id.webview);
        mWebView.setListener(this, this);
        mWebView.setGeolocationEnabled(false);
        mWebView.setMixedContentAllowed(true);
        mWebView.setCookiesEnabled(true);
        mWebView.setThirdPartyCookiesEnabled(true);

        mProgressBar = findViewById(R.id.mProgressBar);

        mWebView.setWebViewClient(new WebViewClient() {
            public boolean shouldOverrideUrlLoading(WebView view, String url) {
                if (url.startsWith("fcm:")) {
                    String fcm = mobile_website_url+"?fcm="+fcm_token();
                    aswm_view(fcm,false, asw_error_counter);
                    Log.d("OFFLINE_FCM_TOKEN",fcm);
                    return true;
                    // opening external URLs in android default web browser
                } else if (Config.EXTURL_URL && !aswm_host(url).equals(SMART_HOST)) {
                    aswm_view(url,true, asw_error_counter);

                    // else return false for no special action
                }
                // Return true to override url loading (In this case do
                // nothing).
                return super.shouldOverrideUrlLoading(view, url);
            }

            @Override
            public void onPageStarted(WebView view, String url, Bitmap favicon) {
                showInterstitial();
                mProgressBar.setVisibility(View.VISIBLE);
            }
            @Override
            public void onPageFinished(WebView view, String url) {
                mProgressBar.setVisibility(View.GONE);
                isConnected = mConnectionDetector.isConnectingToInternet();

                if(!isConnected){
                    errorLayout.setVisibility(View.VISIBLE);
                    tryAgainButtonLayout.setVisibility(View.GONE);
                    refreshButtonLayout.setVisibility(View.VISIBLE);

                } else {
                    errorLayout.setVisibility(View.GONE);

                }
            }
         });

        chromeClient = new SmartChromeClient(mActivity, mWebView, mProgressBar);
        mWebView.setWebChromeClient(chromeClient);

        Button button = findViewById(R.id.search);
        button.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                searchView.showSearch();
            }
        });

        searchView = findViewById(R.id.search_view);
        searchView.setVoiceSearch(true);
        searchView.setCursorDrawable(R.drawable.custom_cursor);
        searchView.setEllipsize(true);
        searchView.setSuggestions(getResources().getStringArray(R.array.query_suggestions));
        searchView.setOnQueryTextListener(new MaterialSearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query) {
                String url = Config.WebSearch+query;
                aswm_view(url,false,asw_error_counter);

                return true;
            }

            @Override
            public boolean onQueryTextChange(String newText) {
                return false;
            }
        });


        searchView.setOnSearchViewListener(new MaterialSearchView.SearchViewListener() {
            @Override
            public void onSearchViewShown() {
                //Do some magic
            }

            @Override
            public void onSearchViewClosed() {
                //Do some magic
            }
        });

        // requesting new FCM token; updating final cookie variable
        fcm_token();

        // notification manager
        NotificationManager notificationManager = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);

        if(Build.VERSION.SDK_INT >= 26) {
            NotificationChannel notificationChannel = new NotificationChannel(fcm_channel,String.valueOf(R.string.notification_channel_name), NotificationManager.IMPORTANCE_HIGH);
            notificationChannel.setDescription(String.valueOf(R.string.notification_channel_desc));
            notificationChannel.setLightColor(Color.RED);
            notificationChannel.enableVibration(true);
            notificationChannel.setShowBadge(true);
            assert notificationManager != null;
            notificationManager.createNotificationChannel(notificationChannel);
            notificationManager.createNotificationChannel(notificationChannel);
        }

        mWebView.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View v) {
                return true;
            }
        });

        //Reading incoming intents
        Intent read_int = getIntent();
        Log.d("INTENT", read_int.toUri(0));
        String uri = read_int.getStringExtra("uri");
        String share = read_int.getStringExtra("s_uri");
        String share_img = read_int.getStringExtra("s_img");

        if(share != null) {
            //Processing shared content
            Log.d("SHARE INTENT",share);
            Matcher matcher = urlPattern.matcher(share);
            String urlStr = "";
            if(matcher.find()){
                urlStr = matcher.group();
                if(urlStr.startsWith("(") && urlStr.endsWith(")")) {
                    urlStr = urlStr.substring(1, urlStr.length() - 1);
                }
            }
            String red_url = Config.SHARE_URL+"?text="+share+"&link="+urlStr+"&image_url=";
            //Toast.makeText(MainActivity.this, "SHARE: "+red_url+"\nLINK: "+urlStr, Toast.LENGTH_LONG).show();
            aswm_view(red_url, false, asw_error_counter);

        }else if(share_img != null) {
            //Processing shared content
            Log.d("SHARE INTENT",share_img);
            Toast.makeText(MainActivity.this, share_img, Toast.LENGTH_LONG).show();
            aswm_view(mobile_website_url, false, asw_error_counter);

        }else if(uri != null) {
            //Opening notification
            Log.d("NOTIFICATION INTENT",uri);
            aswm_view(uri, false, asw_error_counter);

        }else{
            //Rendering the default URL
            Log.d("MAIN INTENT",mobile_website_url);
            aswm_view(mobile_website_url, false, asw_error_counter);
        }

        if(Config.ADMOB) {
            MobileAds.initialize(this, getString(R.string.admob_app_id));

            mAdView = findViewById(R.id.adView);
            AdRequest adRequest = new AdRequest.Builder().build();
            mAdView.loadAd(adRequest);

            AdView adView = new AdView(this);
            adView.setAdSize(AdSize.BANNER);
            adView.setAdUnitId(getString(R.string.admob_banner_id));
        }

        if (getIntent().getData() != null) {
            String path     = getIntent().getDataString();
            /*
            If you want to check or use specific directories or schemes or hosts

            Uri data        = getIntent().getData();
            String scheme   = data.getScheme();
            String host     = data.getHost();
            List<String> pr = data.getPathSegments();
            String param1   = pr.get(0);
            */
            aswm_view(path, false, asw_error_counter);
        }

        // RateApp
        if (Config.rateActive) {
            app_rate(this);
        }

    }

    /**
     * Show an interstitial ad
     */
    private void showInterstitial(){
        //if (fromPager) return;
        if (getResources().getString(R.string.admob_inter_id).length() == 0) return;

        if (interstitialCount == (Config.INTERSTITIAL_PAGE_INTERVAL - 1)) {
            final InterstitialAd mInterstitialAd = new InterstitialAd(mActivity);
            mInterstitialAd.setAdUnitId(getResources().getString(R.string.admob_inter_id));
            AdRequest adRequestInter = new AdRequest.Builder().addTestDevice(AdRequest.DEVICE_ID_EMULATOR).build();
            mInterstitialAd.setAdListener(new AdListener() {
                @Override
                public void onAdLoaded() {
                    mInterstitialAd.show();
                }
            });
            mInterstitialAd.loadAd(adRequestInter);

            interstitialCount = 0;
        } else {
            interstitialCount++;
        }

    }

    @SuppressLint("NewApi")
    @Override
    protected void onResume() {
        super.onResume();
        mWebView.onResume();
        // ...
        //Coloring the "recent apps" tab header; doing it onResume, as an insurance
        if (Build.VERSION.SDK_INT >= 23) {
            Bitmap bm = BitmapFactory.decodeResource(getResources(), R.mipmap.ic_launcher);
            ActivityManager.TaskDescription taskDesc;
            taskDesc = new ActivityManager.TaskDescription(getString(R.string.app_name), bm, getColor(R.color.colorPrimary));
            MainActivity.this.setTaskDescription(taskDesc);
        }
    }

    @SuppressLint("NewApi")
    @Override
    protected void onPause() {
        mWebView.onPause();
        // ...
        super.onPause();
    }

    @Override
    protected void onDestroy() {
        mWebView.onDestroy();
        // ...
        super.onDestroy();
    }

    @Override
    public void onPageError(int errorCode, String description, String failingUrl) {
        Toast.makeText(getApplicationContext(), getString(R.string.went_wrong), Toast.LENGTH_SHORT).show();

    }

    @SuppressLint("NewApi")
    @Override
    public void onDownloadRequested(String url, String suggestedFilename, String mimeType, long contentLength, String contentDisposition, String userAgent) {

        if (!check_permission(2)) {
            ActivityCompat.requestPermissions(MainActivity.this, new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE, Manifest.permission.READ_EXTERNAL_STORAGE}, file_perm);
        } else {

            if (AdvancedWebView.handleDownload(this, url, suggestedFilename)) {
                // download successfully handled
                Toast.makeText(getApplicationContext(), getString(R.string.dl_downloading2), Toast.LENGTH_LONG).show();

            } else {
                // download couldn't be handled because user has disabled download manager app on the device
                Toast.makeText(getApplicationContext(), getString(R.string.went_wrong), Toast.LENGTH_SHORT).show();
            }
        }
    }

    //Random ID creation function to help get fresh cache every-time webview reloaded
    public String random_id() {
        return new BigInteger(130, random).toString(32);
    }

    //Opening URLs inside webview with request
    void aswm_view(String url, Boolean tab, int error_counter) {
        if(error_counter > 2){
            asw_error_counter = 0;
            smart_exit();
        }else {
            if(tab){
                if(Config.Browser_TAB) {
                    CustomTabsIntent.Builder intentBuilder = new CustomTabsIntent.Builder();
                    intentBuilder.setToolbarColor(ContextCompat.getColor(this, R.color.colorPrimary));
                    intentBuilder.setSecondaryToolbarColor(ContextCompat.getColor(this, R.color.colorPrimaryDark));
                    intentBuilder.setStartAnimations(this, android.R.anim.slide_in_left, android.R.anim.slide_out_right);
                    intentBuilder.setExitAnimations(this, android.R.anim.slide_in_left, android.R.anim.slide_out_right);
                    CustomTabsIntent customTabsIntent = intentBuilder.build();
                    try {
                        customTabsIntent.launchUrl(MainActivity.this, Uri.parse(url));
                    } catch (ActivityNotFoundException e) {
                        Intent intent = new Intent(Intent.ACTION_VIEW);
                        intent.setData(Uri.parse(url));
                        startActivity(intent);
                    }
                }else{
                    Intent intent = new Intent(Intent.ACTION_VIEW);
                    intent.setData(Uri.parse(url));
                    startActivity(intent);
                }
            } else {
                if (url.contains("?")) { // check to see whether the url already has query parameters and handle appropriately.
                    url += "&";
                } else {
                    url += "?";
                }
                url += "rid=" + random_id();
                mWebView.loadUrl(url);
            }
        }
    }

    private static final Pattern urlPattern = Pattern.compile(
            "(?:^|[\\W])((ht|f)tp(s?):\\/\\/|www\\.)"+"(([\\w\\-]+\\.){1,}?([\\w\\-.~]+\\/?)*"+"[\\p{Alnum}.,%_=?&#\\-+()\\[\\]\\*$~@!:/{};']*)",Pattern.CASE_INSENSITIVE | Pattern.MULTILINE | Pattern.DOTALL);

    //Getting host name
    public static String aswm_host(String url){
        if (url == null || url.length() == 0) {
            return "";
        }
        int dslash = url.indexOf("//");
        if (dslash == -1) {
            dslash = 0;
        } else {
            dslash += 2;
        }
        int end = url.indexOf('/', dslash);
        end = end >= 0 ? end : url.length();
        int port = url.indexOf(':', dslash);
        end = (port > 0 && port < end) ? port : end;
        Log.w("URL Host: ",url.substring(dslash, end));
        return url.substring(dslash, end);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.main, menu);

        MenuItem item = menu.findItem(R.id.search);
        searchView.setMenuItem(item);

        return true;
    }

    @Override
    public void onBackPressed() {
        if (mWebView.canGoBack()) {
            mWebView.goBack();
        } else {
            if (searchView.isSearchOpen()) {
                searchView.closeSearch();
            } else {

                if ((System.currentTimeMillis() - exitTime) > PRESS_BACK_EXIT_GAP) {

                    Toast.makeText(mContext, "Are you sure to Exit",
                            Toast.LENGTH_SHORT).show();
                    exitTime = System.currentTimeMillis();
                } else {

                    super.onBackPressed();
                }
            }
        }
    }

    public static int fcm_id(){
        //Date now = new Date();
        //Integer.parseInt(new SimpleDateFormat("ddHHmmss",  Locale.US).format(now));
        return 1;
    }

    public String fcm_token(){
        FirebaseInstanceId.getInstance().getInstanceId().addOnSuccessListener( MainActivity.this, instanceIdResult -> {
            fcm_token = instanceIdResult.getToken();
            if(true_online) {
                CookieManager cookieManager = CookieManager.getInstance();
                cookieManager.setAcceptCookie(true);
                cookieManager.setCookie(Config.mobile_website_url, "FCM_TOKEN="+fcm_token);
                Log.d("FCM_BAKED","YES");
                //Log.d("COOKIES: ", cookieManager.getCookie(ASWV_URL));
            }
            Log.d("REQ_FCM_TOKEN", fcm_token);
        }).addOnFailureListener(e -> Log.d("REQ_FCM_TOKEN", "FAILED"));
        return fcm_token;
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        mWebView.onActivityResult(requestCode, resultCode, data);
    }

    //Checking if particular permission is given or not
    public boolean check_permission(int permission){
        switch(permission){
            case 1:
                return ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED;

            case 2:
                return ContextCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED;

            case 3:
                return ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED;

        }
        return false;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        if( id == R.id.refresh){
            refresh();

            return true;
        }else if (id == R.id.home){
            aswm_view(mobile_website_url,false,asw_error_counter);

            return true;
        }else if (id == R.id.nav_call) {
            String phone = "+91";
            Intent intent = new Intent(Intent.ACTION_DIAL, Uri.fromParts("tel", phone, null));
            startActivity(intent);

            return true;
        }else if (id == R.id.about) {
            aswm_view(Config.aboutUrl,false,asw_error_counter);
            return true;
        }else if (id == R.id.close) {
            exitDialog();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    // Share Page
    private void ShareActivity() {
        Intent shareIntent = new Intent(Intent.ACTION_SEND);
        shareIntent.setType("text/plain");
        String appname = getString(R.string.app_name);
        // This will put the share text:
        // "I came across "BrowserTitle" using ":-appname"
        shareIntent
                .putExtra(
                        Intent.EXTRA_TEXT,
                        (getText(R.string.share1)
                                + " "
                                + "*"+mWebView.getTitle()+"*"
                                + " "
                                + getText(R.string.share2)
                                + " "
                                + ":-"+" *"+appname+"*"
                                + " " + mWebView.getUrl()));
        startActivity(Intent.createChooser(shareIntent,
                getText(R.string.sharetitle)));
    }

    public void smart_exit(){
        Intent intent = new Intent(Intent.ACTION_MAIN);
        intent.addCategory(Intent.CATEGORY_HOME);
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        startActivity(intent);
    }

    // Exit Dialog
    public void exitDialog() {
        Log.d(tag, "In the exitDialog()");
        AlertDialog.Builder exitAlertDialog = new AlertDialog.Builder(MainActivity.this);

        exitAlertDialog.setTitle("Confirm Exit")
                .setMessage("Do you want to quit?")
                .setPositiveButton("Okay", new OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {

                        //===>> Logging
                        Log.d(tag, "Exit Dialog = true");
                        finish();
                    }
                })
                .setNegativeButton("Cancel", new OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {

                        //===>> Logging
                        Log.d(tag, "Exit Dialog = false");
                    }
                }).create();

        exitAlertDialog.show();
    }

    // Refresh
    public void refresh() {
        mWebView.stopLoading();
        mWebView.reload();
    }

    public boolean onNavigationItemSelected(MenuItem item) {
        int id = item.getItemId();
        if (id == R.id.nav_share) {
            ShareActivity();

        } else if (id == R.id.nav_intro) {
            aswm_view(Config.Intro_Url,false,asw_error_counter);
        } else if (id == R.id.nav_products) {
            aswm_view(Config.Product_Url,false,asw_error_counter);
        } else if (id == R.id.nav_services) {
            aswm_view(Config.Services_Url,false,asw_error_counter);
        } else if (id == R.id.nav_help) {
            aswm_view(Config.Help_Url,false,asw_error_counter);
        } else if (id == R.id.nav_Website) {
            String url = Config.WebSite_Url;
            Intent i = new Intent(Intent.ACTION_VIEW);
            i.setData(Uri.parse(url));
            startActivity(i);
        } else if (id == R.id.privacy_policy) {
            aswm_view(Config.PrivacyPolicyUrl,false,asw_error_counter);
        } else if (id == R.id.nav_RateUs) {
            String url = Config.PlayStoreUrl;
            Intent i = new Intent(Intent.ACTION_VIEW);
            i.setData(Uri.parse(url));
            startActivity(i);
        }

        DrawerLayout drawer = findViewById(R.id.drawer_layout);
        drawer.closeDrawer(GravityCompat.START);
        return true;
    }

        private void app_rate(Context mContext) {
            SharedPreferences prefs = mContext.getSharedPreferences("apprater", 0);
            if (prefs.getBoolean("dntshow", false)) {
                return;
            }

            SharedPreferences.Editor editor = prefs.edit();

            // Increment launch counter
            long launch_count = prefs.getLong("launch_count", 0) + 1;
            editor.putLong("launch_count", launch_count);


            // Wait at least n of launches
            if (launch_count >= usesBeforeRateLaunch) {
                showRateDialog(mContext, editor);
            }

            editor.apply();
        }

        private void showRateDialog(final Context mContext, final SharedPreferences.Editor editor) {
            SmartRate.Rate(MainActivity.this
                    , "Rate Us"
                    , "Tell others what you think about this app"
                    , "Continue"
                    , "Please take a moment and rate us on Google Play"
                    , "click here"
                    , "Cancel"
                    , "Thanks for the feedback"
                    , Color.parseColor("#0878D1")
                    , 4
                    , new SmartRate.CallBack_UserRating() {
                        @Override
                        public void userRating(int rating) {
                            // Do something
                            // maybe from now disable this button
                            String url = Config.PlayStoreUrl;
                            Intent i = new Intent(Intent.ACTION_VIEW);
                            i.setData(Uri.parse(url));
                            startActivity(i);
                            editor.putBoolean("dntshow", true);
                            editor.commit();
                        }
                    }
            );
        }

}