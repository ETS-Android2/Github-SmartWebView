package com.android.smartwebview.view;

import android.graphics.Bitmap;

import androidx.appcompat.app.AppCompatActivity;
import android.view.View;
import android.graphics.BitmapFactory;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.widget.ProgressBar;
import android.widget.FrameLayout;
import android.webkit.GeolocationPermissions;
import android.webkit.PermissionRequest;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.util.Log;
import android.content.DialogInterface.OnClickListener;
import android.widget.Toast;
import com.android.smartwebview.R;
import com.android.smartwebview.Config;

public class SmartChromeClient extends WebChromeClient {

    // Logs
    private String tag = "state";
    // Geo-location
    private Boolean geoLocationValue = false;

        private View mCustomView;
        private WebChromeClient.CustomViewCallback mCustomViewCallback;
        private int mOriginalOrientation;
        private int mOriginalSystemUiVisibility;

    private ProgressBar mProgressBar;
    private AppCompatActivity activity;
    private AdvancedWebView mWebView;
    private boolean isVideoFullscreen; // Indicates if the video is being displayed using a custom view (typically full-screen)
    public SmartChromeClient(
            AppCompatActivity activity,
            AdvancedWebView mWebView,
            ProgressBar mProgressBar)
    {
        super();
        this.activity = activity;
        this.mWebView = mWebView;
        this.mProgressBar = mProgressBar;
        this.isVideoFullscreen = false;
    }

    @Override
    public void onProgressChanged(WebView view, int newProgress) {
        if (Config.SMART_PBAR) {
            if (newProgress < 100) {
                mProgressBar.setVisibility(View.VISIBLE);
                mProgressBar.setProgress(view.getProgress());
            } else {
                mProgressBar.setProgress(0);
                mProgressBar.setVisibility(View.GONE);
            }
        }
    }

    @Override
    public void onReceivedTitle(WebView view,String title){
        super.onReceivedTitle(view,title);
    }

        public Bitmap getDefaultVideoPoster() {
            if (mCustomView == null) {
                return null;
            }
            return BitmapFactory.decodeResource(activity.getResources(), 2130837573);
        }

        public void onHideCustomView() {
            ((FrameLayout) activity.getWindow().getDecorView()).removeView(this.mCustomView);
            this.mCustomView = null;
            activity.getWindow().getDecorView().setSystemUiVisibility(this.mOriginalSystemUiVisibility);
            activity.setRequestedOrientation(this.mOriginalOrientation);
            this.mCustomViewCallback.onCustomViewHidden();
            this.mCustomViewCallback = null;
        }

        public void onShowCustomView(View paramView, WebChromeClient.CustomViewCallback paramCustomViewCallback) {
            if (this.mCustomView != null) {
                onHideCustomView();
                return;
            }
            this.mCustomView = paramView;
            this.mOriginalSystemUiVisibility = activity.getWindow().getDecorView().getSystemUiVisibility();
            this.mOriginalOrientation = activity.getRequestedOrientation();
            this.mCustomViewCallback = paramCustomViewCallback;
            ((FrameLayout) activity.getWindow().getDecorView()).addView(this.mCustomView, new FrameLayout.LayoutParams(-1, -1));
            activity.getWindow().getDecorView().setSystemUiVisibility(3846);
        }


        @Override
        public void onGeolocationPermissionsShowPrompt(final String origin,
                                                       final GeolocationPermissions.Callback callback) {

            //===>> Logging
            Log.d(tag, "In the OnGeoLocationPermissions");

            // Always grant permission since the app itself requires location
            // permission and the user has therefore already granted it
            // Retrieve GeoLocation Setting
            SharedPreferences pref = activity.getSharedPreferences("MyPref", 0); // 0 - for private mode
            geoLocationValue = pref.getBoolean("geoLocation", false);

            // GeoLocation Dialog
            if (!geoLocationValue) {
                AlertDialog.Builder geoAlertDialog = new AlertDialog.Builder(activity);
                geoAlertDialog.setIcon(R.drawable.ic_launcher)
                        .setTitle(R.string.app_name)
                        .setMessage("Would Like to Use Your Current Location")
                        .setPositiveButton("Ok", new OnClickListener() {

                            // OnClick
                            public void onClick(DialogInterface dialog, int id) {
                                callback.invoke(origin, true, false);
                                 Toast.makeText(activity, activity.getResources().getString(R.string.went_wrong), Toast.LENGTH_SHORT).show();
                                SharedPreferences pref = activity.getSharedPreferences("MyPref", 0);
                                Editor editor = pref.edit();
                                editor.putBoolean("geoLocation", true);
                                editor.apply();
                                Log.d(tag, "GeoLocation = true");
                                mProgressBar.setVisibility(View.VISIBLE);
                             
                            }

                        }).setNegativeButton("Don't Allow", new OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        callback.invoke(origin, false, false);
                    }
                }).create();

                // GeoLocation Dialog Show
                geoAlertDialog.show();

            } else {
                callback.invoke(origin, true, false);
            }
        }

        @Override
        public void onPermissionRequest(final PermissionRequest request) {
            request.grant(request.getResources());

        }

    public boolean onBackPressed()
    {
        if (isVideoFullscreen)
        {
            onHideCustomView();
            return true;
        }
        else
        {
            return false;
        }
    }

}
